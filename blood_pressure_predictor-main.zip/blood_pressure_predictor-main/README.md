# blood_pressure_predictor
 A web app developed by Python/Flask.
 
 Play at http://mydcxiao.pythonanywhere.com
